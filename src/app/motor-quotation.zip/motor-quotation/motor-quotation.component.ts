import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { NotificationService } from '../shared/services/notification.service';
import { FormStateService } from '../shared/services/form-state.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

interface QuoteResult {
  premium: number;
  coverageType: string;
  deductible: number;
}

@Component({
  standalone: false,
  selector: 'app-motor-quotation',
  templateUrl: './motor-quotation.component.html',
  styleUrls: ['./motor-quotation.component.css']
})
export class MotorQuotationComponent implements OnInit, OnDestroy {
  currentStep = 0;
  isLinear = true;
  isMobile = false;

  vehicleFormGroup!: FormGroup;
  personalFormGroup!: FormGroup;
  coverageFormGroup!: FormGroup;

  quoteResult: QuoteResult | null = null;
  isCalculating = false;

  // Auto-save status tracking
  autoSaveStatus: 'idle' | 'saving' | 'saved' = 'idle';
  private destroy$ = new Subject<void>();

  // Data for dropdowns
  vehicleMakes = ['Toyota', 'Honda', 'Ford', 'BMW', 'Mercedes', 'Audi', 'Volkswagen', 'Nissan', 'Mazda', 'Chevrolet'];
  vehicleModels: { [key: string]: string[] } = {
    'Toyota': ['Camry', 'Corolla', 'RAV4', 'Highlander', 'Prius'],
    'Honda': ['Accord', 'Civic', 'CR-V', 'Pilot', 'HR-V'],
    'Ford': ['F-150', 'Mustang', 'Explorer', 'Escape', 'Edge'],
    'BMW': ['3 Series', '5 Series', 'X3', 'X5', 'X7'],
    'Mercedes': ['C-Class', 'E-Class', 'GLC', 'GLE', 'S-Class'],
    'Audi': ['A4', 'A6', 'Q5', 'Q7', 'A3'],
    'Volkswagen': ['Golf', 'Jetta', 'Passat', 'Tiguan', 'Atlas'],
    'Nissan': ['Altima', 'Sentra', 'Rogue', 'Murano', 'Pathfinder'],
    'Mazda': ['Mazda3', 'Mazda6', 'CX-5', 'CX-9', 'MX-5'],
    'Chevrolet': ['Silverado', 'Malibu', 'Equinox', 'Tahoe', 'Corvette']
  };

  currentModels: string[] = [];
  years: number[] = [];
  coverageTypes = [
    { value: 'comprehensive', label: 'Comprehensive', description: 'Full coverage including collision, theft, and natural disasters' },
    { value: 'third-party', label: 'Third Party', description: 'Covers damage to other vehicles and property' },
    { value: 'third-party-fire-theft', label: 'Third Party + Fire & Theft', description: 'Third party coverage plus fire and theft protection' }
  ];

  deductibles = [250, 500, 1000, 2500, 5000];
  parkingTypes = ['Garage', 'Driveway', 'Street', 'Carport', 'Parking Lot'];

  constructor(
    private formBuilder: FormBuilder,
    private breakpointObserver: BreakpointObserver,
    private notificationService: NotificationService,
    private formStateService: FormStateService
  ) {
    // Generate years from current year back 25 years
    const currentYear = new Date().getFullYear();
    for (let i = currentYear; i >= currentYear - 25; i--) {
      this.years.push(i);
    }
  }

  ngOnInit(): void {
    // Monitor screen size for responsive behavior
    this.breakpointObserver.observe([Breakpoints.Handset])
      .pipe(takeUntil(this.destroy$))
      .subscribe(result => {
        this.isMobile = result.matches;
      });

    // Initialize form groups with validation
    this.vehicleFormGroup = this.formBuilder.group({
      make: ['', Validators.required],
      model: ['', Validators.required],
      year: ['', Validators.required],
      registration: ['', [Validators.required, Validators.pattern(/^[A-Z0-9]{2,10}$/)]],
      vehicleValue: ['', [Validators.required, Validators.min(1000), Validators.max(500000)]]
    });

    this.personalFormGroup = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      dateOfBirth: ['', Validators.required],
      licenseNumber: ['', [Validators.required, Validators.minLength(5)]]
    });

    this.coverageFormGroup = this.formBuilder.group({
      coverageType: ['comprehensive', Validators.required],
      deductible: [500, Validators.required],
      annualMileage: ['', [Validators.required, Validators.min(0), Validators.max(100000)]],
      parkingType: ['', Validators.required],
      roadsideAssistance: [false],
      rentalCarCoverage: [false]
    });

    // Restore saved form state if available
    this.restoreSavedFormState();

    // Enable auto-save for all form groups
    this.formStateService.enableAutoSave('motor-quote-vehicle', this.vehicleFormGroup);
    this.formStateService.enableAutoSave('motor-quote-personal', this.personalFormGroup);
    this.formStateService.enableAutoSave('motor-quote-coverage', this.coverageFormGroup);

    // Subscribe to auto-save status updates
    this.formStateService.autoSaveStatus$
      .pipe(takeUntil(this.destroy$))
      .subscribe(status => {
        if (status.status === 'saving') {
          this.autoSaveStatus = 'saving';
          // Reset to saved after 1 second
          setTimeout(() => {
            this.autoSaveStatus = 'saved';
            // Reset to idle after 2 more seconds
            setTimeout(() => {
              this.autoSaveStatus = 'idle';
            }, 2000);
          }, 1000);
        }
      });

    // Listen to make changes to update model dropdown
    this.vehicleFormGroup.get('make')?.valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe(make => {
        this.onMakeChange(make);
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private restoreSavedFormState(): void {
    // Check if there's saved state for each form group
    const savedVehicleData = this.formStateService.restoreFormState('motor-quote-vehicle');
    const savedPersonalData = this.formStateService.restoreFormState('motor-quote-personal');
    const savedCoverageData = this.formStateService.restoreFormState('motor-quote-coverage');

    let hasRestoredData = false;

    if (savedVehicleData) {
      this.vehicleFormGroup.patchValue(savedVehicleData);
      // If make is restored, update the models dropdown
      if (savedVehicleData.make) {
        this.currentModels = this.vehicleModels[savedVehicleData.make] || [];
      }
      hasRestoredData = true;
    }

    if (savedPersonalData) {
      this.personalFormGroup.patchValue(savedPersonalData);
      hasRestoredData = true;
    }

    if (savedCoverageData) {
      this.coverageFormGroup.patchValue(savedCoverageData);
      hasRestoredData = true;
    }

    // Show notification if we restored saved data
    if (hasRestoredData) {
      this.notificationService.info('We\'ve restored your previous form data. 📋');
    }
  }

  onMakeChange(make: string): void {
    this.currentModels = this.vehicleModels[make] || [];
    this.vehicleFormGroup.patchValue({ model: '' });
  }

  getStepIcon(step: number): string {
    if (step < this.currentStep) {
      return 'check_circle';
    }
    switch (step) {
      case 0: return 'directions_car';
      case 1: return 'person';
      case 2: return 'shield';
      case 3: return 'request_quote';
      default: return 'circle';
    }
  }

  getStepLabel(step: number): string {
    switch (step) {
      case 0: return 'Vehicle Info';
      case 1: return 'Personal Details';
      case 2: return 'Coverage Options';
      case 3: return 'Your Quote';
      default: return '';
    }
  }

  getProgressPercentage(): number {
    return Math.round(((this.currentStep + 1) / 4) * 100);
  }

  nextStep(): void {
    if (this.currentStep < 3) {
      this.currentStep++;
      if (this.currentStep === 3) {
        this.calculateQuote();
      }
    }
  }

  previousStep(): void {
    if (this.currentStep > 0) {
      this.currentStep--;
    }
  }

  canProceed(): boolean {
    switch (this.currentStep) {
      case 0:
        return this.vehicleFormGroup.valid;
      case 1:
        return this.personalFormGroup.valid;
      case 2:
        return this.coverageFormGroup.valid;
      default:
        return false;
    }
  }

  calculateQuote(): void {
    this.isCalculating = true;

    // Simulate API call with setTimeout
    setTimeout(() => {
      const vehicleValue = this.vehicleFormGroup.value.vehicleValue;
      const vehicleYear = this.vehicleFormGroup.value.year;
      const coverageType = this.coverageFormGroup.value.coverageType;
      const deductible = this.coverageFormGroup.value.deductible;
      const annualMileage = this.coverageFormGroup.value.annualMileage;

      // Calculate premium based on various factors
      let basePremium = vehicleValue * 0.05; // 5% of vehicle value

      // Adjust for vehicle age
      const vehicleAge = new Date().getFullYear() - vehicleYear;
      basePremium *= (1 - vehicleAge * 0.02); // 2% discount per year

      // Adjust for coverage type
      if (coverageType === 'third-party') {
        basePremium *= 0.4;
      } else if (coverageType === 'third-party-fire-theft') {
        basePremium *= 0.6;
      }

      // Adjust for deductible (higher deductible = lower premium)
      basePremium *= (1 - deductible / 10000);

      // Adjust for mileage (higher mileage = higher premium)
      basePremium *= (1 + annualMileage / 50000);

      // Round to 2 decimal places
      const premium = Math.round(basePremium * 100) / 100;

      this.quoteResult = {
        premium,
        coverageType: this.getCoverageLabel(coverageType),
        deductible
      };

      // Clear saved form state after successful quote calculation
      this.formStateService.clearFormState('motor-quote-vehicle');
      this.formStateService.clearFormState('motor-quote-personal');
      this.formStateService.clearFormState('motor-quote-coverage');

      this.isCalculating = false;
      this.notificationService.success('Your quote has been calculated successfully!');
    }, 1500);
  }

  getCoverageLabel(value: string): string {
    const coverage = this.coverageTypes.find(c => c.value === value);
    return coverage ? coverage.label : value;
  }

  startNewQuote(): void {
    this.currentStep = 0;
    this.quoteResult = null;
    this.vehicleFormGroup.reset();
    this.personalFormGroup.reset();
    this.coverageFormGroup.patchValue({
      coverageType: 'comprehensive',
      deductible: 500
    });

    // Clear saved form state when starting a new quote
    this.formStateService.clearFormState('motor-quote-vehicle');
    this.formStateService.clearFormState('motor-quote-personal');
    this.formStateService.clearFormState('motor-quote-coverage');
  }

  getErrorMessage(formGroup: FormGroup, field: string): string {
    const control = formGroup.get(field);
    if (!control) return '';

    if (control.hasError('required')) {
      return 'This field is required';
    }
    if (control.hasError('email')) {
      return 'Please enter a valid email address';
    }
    if (control.hasError('pattern')) {
      if (field === 'registration') {
        return 'Registration must be 2-10 alphanumeric characters';
      }
      if (field === 'phone') {
        return 'Phone number must be exactly 10 digits';
      }
    }
    if (control.hasError('minlength')) {
      return `Must be at least ${control.errors?.['minlength'].requiredLength} characters`;
    }
    if (control.hasError('min')) {
      return `Minimum value is ${control.errors?.['min'].min}`;
    }
    if (control.hasError('max')) {
      return `Maximum value is ${control.errors?.['max'].max}`;
    }
    return '';
  }

  /**
   * Check if a form field is valid and has been touched
   */
  isFieldValid(formGroup: FormGroup, fieldName: string): boolean {
    const field = formGroup.get(fieldName);
    return field ? field.valid && (field.dirty || field.touched) : false;
  }

  /**
   * Check if a form field should show error
   */
  shouldShowError(formGroup: FormGroup, fieldName: string): boolean {
    const field = formGroup.get(fieldName);
    return field ? field.invalid && (field.dirty || field.touched) : false;
  }

  /**
   * Check if comprehensive coverage is selected
   */
  isComprehensiveCoverage(): boolean {
    return this.coverageFormGroup?.get('coverageType')?.value === 'comprehensive';
  }

  /**
   * Check if vehicle is older than 10 years
   */
  isVehicleOld(): boolean {
    const year = this.vehicleFormGroup?.get('year')?.value;
    if (!year) return false;
    const vehicleAge = new Date().getFullYear() - year;
    return vehicleAge > 10;
  }

  /**
   * Get vehicle age in years
   */
  getVehicleAge(): number {
    const year = this.vehicleFormGroup?.get('year')?.value;
    if (!year) return 0;
    return new Date().getFullYear() - year;
  }
}
